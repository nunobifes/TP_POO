#include "Mundo.h"



using namespace std;

Mundo::Mundo() {

}

/*void Mundo::setNinho(Ninhos* n) {
	this->ni = n;			
}

void Mundo::setFormiga(Formiga* f) {
	this->form = f;
}
*/
Mundo::~Mundo() {

}