//Um ninho serve essencialmente para criar 
//novas formigas e tamb�m como ref�gio de algumas das formigas existentes na sua comunidade.


#include "Ninhos.h"


void Ninhos::setId(int i) {
	this->id = i;
}

void Ninhos::setEnergia(int e) {
	this->energia = e;
}

void Ninhos::set_PercEnerg(int p){
	this->perc_energ = p;
}

void Ninhos::set_TransfEnerg(int t) {
	this->perc_energ = t;
}

/*void Ninhos::insereNinho(Formiga *fr) {
	v.push_back(fr);
	fr->LigaNinho(this);

}*/

/*void Ninhos::setPosX(int x) {
	this->x = x;
}

void Ninhos::setPosY(int y) {
	this->y = y;
}
*/
int Ninhos::getPosX() const{
	return this->x;
}

int Ninhos::getPosY() const {
	return this->y;
}

void Ninhos::set_coord(int c, int l) {
	this->x = c;
	this->y = l;
}



Ninhos::~Ninhos() {

}