#include "Formiga.h"


/*void Formiga::setID(int id) {
	this->ident;
}*/


void Formiga::setEnergia(int e) {			
	this->energia=e;
}


void Formiga::setVisao(int vi) {
	this->visao_form = vi;
}

void Formiga::setMove(int m) {
	this->mov_form = m;

}
void Formiga::setPosX(int x) {
	this->x = x;
}

void Formiga::setPosY(int y) {
	this->y = y;
}
