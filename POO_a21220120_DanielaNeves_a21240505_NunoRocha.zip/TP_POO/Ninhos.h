#ifndef NINHOS
#define NINHOS

#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <windows.h>
#include <vector>

#include "Formiga.h"

using namespace std;

//class Formiga;

class Ninhos {
	int id;						// Atraves do id do ninho a formiga sabe a que ninho pertence....
	int energia;
	int perc_energ;
	int transf_energ;
	int x, y;
	vector <Formiga*> formiga;

public:


	Ninhos(int id, int e, int p, int t, int x, int y)
		:id(id), energia(e), perc_energ(p), transf_energ(t), x(x), y(y){}

	int getId() const { return id; }
	int getEnergia() const { return energia; }
	int getPosX() const;
	int getPosY() const;

	void setId(int i);
	void setEnergia(int e);
	void set_coord(int l, int c);
	void set_PercEnerg(int p);

	void set_TransfEnerg(int t);
	
	/*
	void setPosX(int x);
	void setPosY(int y);
	*/

	void insereNinho(Formiga *fr);

	~Ninhos();



};

#endif