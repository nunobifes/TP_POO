#ifndef MUNDO
#define MUNDO

#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <windows.h>

#include "Comunidades.h"
using namespace std;

//class Ninhos;
//class Formiga;

class Mundo {

	//Ninhos* ni;
	//Formiga* form;
	vector <Comunidades*> comunidades;
public:
	Mundo();

	//Ninhos* getNinho() {return ni;}
	//Formiga* getFormiga() {return form;}

	//void setNinho(Ninhos* ni);
	//void setFormiga(Formiga* form);

	~Mundo();

	
};

#endif

