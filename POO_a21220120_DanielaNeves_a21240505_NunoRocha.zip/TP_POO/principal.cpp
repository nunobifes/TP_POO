
#include "Consola.h"
#include "Screen.h"
#include "Mundo.h"
#include "Screen.h"
//#include "Comunidades.h"
#include <fstream>

using namespace std;


int main()
{
	
	bool ready = false, flagEnergia = false, flagTam = false, flagPerc = false, flagTransf = true;
	int op, linhas = 0, energia = 0, perc_energ = 0, transf_energ = 1, pos_miga = 0, energia_miga = 0, max_miga = 0;
	//Ninhos* ninhos = nullptr;
	vector <Ninhos *> ninhos;
	//Mundo** mundo;
	string comando;
	Mundo** campo = nullptr;
	

	// "Menu" inicial de configura��o 
	do {
		Consola::setScreenSize(50, 140);
		
		margens();
		intro();
		Consola::gotoxy(2, 47);
		cout << "Comando de configuracao: ";
		getline(cin, comando);
		Consola::clrscr();
		istringstream iss(comando);
		iss >> comando;

		op=cmd_op(comando);
		switch (op) {
			case 1: { // defmundo
				Consola::clrscr();
				iss >> linhas;
				

				if (linhas < 10) {
					Consola::setTextColor(Consola::VERMELHO_CLARO);
					Consola::gotoxy(45, 35);
					cout << "[ERRO] - Mapa demasiado pequeno!!" << endl;
					Consola::setTextColor(Consola::BRANCO);
					linhas = 0;
					int o = 0;
					break;
				}
				else {
					campo = new Mundo*[linhas];
					for (int i = 0; i <= linhas; i++) {
						campo[i] = new Mundo[linhas];
						for (int j = 0; j <= linhas; j++) {
							//campo[i][j].setOcupante(' ');
							//campo[i][j].setNinho(nullptr);
							//campo[i][j].setFormigas(nullptr);
							//campo[i][j].setComunidade(nullptr);
						}


					}
				}
				flagTam = true;
				break;
			}
			case 2: // defen
				//Definir a energia...
				iss >> energia;
				//auto i = ninhos.end();
				//ninhos.push_back(setEnergia(energia));
				flagEnergia = true;
				Consola::setTextColor(Consola::VERDE);
				Consola::gotoxy(2, 13);
				cout << "Energia definida para cada ninho: ";
				Consola::setTextColor(Consola::AZUL_CLARO);
				cout << energia << endl;
				Consola::setTextColor(Consola::BRANCO);
				break;


			case 3: // defpc
				iss >> perc_energ;
				//ninhos->set_PercEnerg(perc_energ);
				flagPerc = true;
				break;
			case 4: // defmi
				iss >> transf_energ;
				//ninhos->set_TransfEnerg(transf_energ);
				break;
			case 5: // defme
				break;
			case 6: //defnm
				break;
			case 7:{ // inicio
					if(flagTam == false || flagEnergia == false || flagPerc ==false){
						Consola::setTextColor(Consola::VERMELHO);
						Consola::gotoxy(2, 13);
						cout << "ERRO!" << endl;
						Consola::setTextColor(Consola::BRANCO);
						cout << "  Nao se pode comecar a jogar sem: " << endl;
						if(flagTam == false)
							cout << "   -Defenir o tamanho do mapa;" << endl;
						if (flagEnergia == false)
							cout << "   -Defenir a energia dos ninhos;" << endl;
						if (flagPerc == false)
							cout << "   -Defenir a percentagem para a cria��o de formigas;" << endl;
					} else {
						ready = true;
					}
				}
				break;
			case 8: { // executa
				//int linhas, colunas, energia, energia_i, energia_t, pos_miga, energia_miga, max_miga;
					string nomeFicheiro;
					iss >> nomeFicheiro;
					Consola::gotoxy(2, 13);
					cout << "Nome do ficheiro: " << nomeFicheiro << endl;
					string linha;
					ifstream dados(nomeFicheiro);
					if (!dados.is_open())
					{
						Consola::setTextColor(Consola::VERMELHO);
						Consola::gotoxy(2, 14);
						cout << "ERRO!" << endl;
						Consola::setTextColor(Consola::BRANCO);
						cout << "  Nao consegui abrir ficheiro!" << endl;
						break;
					}
					else
					{
						Consola::gotoxy(2, 14);
						cout << "Consegui abrir!" << endl;
					}
					
					// linha 1 (defmundo)
					getline(dados, linha);
					istringstream tam(linha);
					tam >> linhas;
					Consola::gotoxy(2, 17);
					flagTam = true;
					cout << "defmundo " << linhas << endl;
					
					// linha 2 (defen)
					getline(dados, linha);
					istringstream mod(linha);
					mod >> energia;
					//ninhos->setEnergia(energia);
					flagEnergia = true;
					cout << "  defen " << energia << endl;
					
					// linha 3 (defpc)
					getline(dados, linha);
					istringstream moda(linha);
					moda >> perc_energ;
					//ninhos->set_PercEnerg(perc_energ);
					flagPerc = true;
					cout << "  defpc " << perc_energ << endl;
					
					// linha 4 (defvt)
					getline(dados, linha);
					istringstream modb(linha);
					modb >> transf_energ;
					//ninhos->set_TransfEnerg(transf_energ);
					cout << "  defvt " << transf_energ << endl;
					
					// linha 5 (defmi)
					getline(dados, linha);
					istringstream modc(linha);
					modc >> pos_miga;
					cout << "  defmi " << pos_miga << endl;
					
					// linha 6 (defme)
					getline(dados, linha);
					istringstream modd(linha);
					modd >> energia_miga;
					cout << "  defme " << energia_miga << endl;
					
					// linha 7 (defnm)
					getline(dados, linha);
					istringstream mode(linha);
					mode >> max_miga;
					cout << "  defnm " << max_miga << endl;	
				}
				break;
			case 9: // limpar
				Consola::clrscr();
				break;
			case 10: // sair
				return 0;
			default:
				Consola::setTextColor(Consola::VERMELHO);
				Consola::gotoxy(2, 13);
				cout << "Comando invalido!" << endl;
				Consola::setTextColor(Consola::BRANCO);
				break;


		}
		Consola::gotoxy(2, 12);
		cout << "linhas-> " << linhas;
		cout << "\tenergia-> " << energia;
		cout << "\tpercentagem-> " << perc_energ;
		cout << "\tenergia transferida-> " << transf_energ;
		cout << '\t';
		
	} while (ready != true);
	
	int linha, coluna;
	//auto ninhosBg = ninhos.begin();
	while(1){
		
		
		ready = false;
		while(ready != true){
			Consola::clrscr();
			margens();
			intro_sim();
			mostra_janela();
			Consola::gotoxy(2, 47);
			cout << "Comando de simulacao: ";
			getline(cin, comando);
			
			istringstream iss(comando);
			iss >> comando;

			op = cmd_sim_op(comando);
			switch (op) {

			case 1:{ // ninho <linha> <coluna>
				iss >> linha;
				iss >> coluna;

				int auxl, auxc;
				for (auto i = 0; i <= 20; i++) {
					if (i == linha)
						auxl = i + 18;
				}
				for (auto i = 0; i <= 20; i++) {
					if (i == coluna)
						auxc = i + 59;
				}

				Consola::gotoxy(auxc, auxl);
				cout << "N";
				Consola::getch();
			}
				break;

			case 2: // criaf <F> <T> <N>
				break;

			case 3: // cria1 <T> <N> <linha> <coluna>
				break;

			case 4: // migalha <linha> <coluna>
				break;

			case 5: // foca <linha> <coluna>
				break;

			case 6: // tempo || tempo <N>
				break;

			case 7: // energninho <N> <E>
				break;

			case 8: // energformiga <linha> <coluna> <E>
				break;

			case 9: // mata <linha> <coluna>
				break;

			case 10: // inseticida <N>
				break;

			case 11: // listamundo
				break;

			case 12: // listaninho <N>
				break;

			case 13: // listaposicao <linha>  <coluna>
				break;

			case 14: // guarda <nome>
				break;

			case 15: // muda <nome>
				break;

			case 16: // apaga <nome>
				break;

			case 17: // sair
				return 0;

			default:
				Consola::setTextColor(Consola::VERMELHO);
				Consola::gotoxy(2, 13);
				cout << "Comando invalido!" << endl;
				Consola::setTextColor(Consola::BRANCO);
				break;
			}
		}
	}

	return 0;

}




